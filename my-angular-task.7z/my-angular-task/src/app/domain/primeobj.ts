import { Obj } from "./obj";
export class PrimeObj implements Obj {

    constructor(public isp?, public fnn_number?, public peak_bandwidth?, public network_sio?, public kbps_sio?, public current_tier?, public last_month_tier?) { }
}