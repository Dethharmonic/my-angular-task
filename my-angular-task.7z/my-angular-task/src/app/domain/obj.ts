export interface Obj {
    isp?;
    fnn_number?;
    peak_bandwidth?;
    network_sio?;
    kbps_sio?;
    current_tier?;
    last_month_tier?;
}

